from django.apps import AppConfig


class UserlogsConfig(AppConfig):
    name = 'userlogs'
